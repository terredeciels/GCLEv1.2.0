package position;

import java.util.List;

/**
 *
 * @author Gilles
 * @param <Case>
 * @param <TypeCoups>
 * @param <Coups>
 * @param <Couleur>
 * @param <Direction>
 * @param <Position>
 * @param <Etat>
 * @param <Booleen>
 * @param <TypePiece>
 * @param <Piece>
 * @param <Rq>
 */
public interface IGenerateur<Case, TypeCoups, Coups, Couleur, Direction, Position, Etat, Booleen, TypePiece, Piece, Rq, Rang> {

    /**
     * ajouter un coups à la liste des coups deplacement et prise
     *
     * @param caseO
     * @param caseX
     * @param type_de_coups
     * @return
     */
    Booleen ajouterCoups(Case caseO, Case caseX, TypeCoups type_de_coups);

    /**
     * ajoute a la liste des coups, la liste des roques possibles
     *
     * @param fCoups
     */
    void traiterRoques(List<Coups> fCoups);

    /**
     * retourne true si les cases d'un roque sont attaqués
     *
     * @param E1ouE8
     * @param F1ouF8
     * @param G1ouG8
     * @param coupsAttaque
     * @return
     */
    Booleen attaqueRoque(Case E1ouE8, Case F1ouF8, Case G1ouG8, List<Coups> coupsAttaque);

    /**
     * retourne couleur de la piece d'une case
     *
     * @param caseO
     * @return
     */
    Couleur couleurPiece(Case caseO);

    /**
     * établit la liste des coups En Passant
     *
     * @param pCoups
     * @param couleur
     */
    void traiterCoupsEP(List<Coups> pCoups, Couleur couleur);

    void ajouterCoups(Piece piece, Case caseO, Case caseX, Piece pieceprise, TypeCoups type_de_coups);

    /**
     * ajoute aux pseudoCoups les coups des pions qui attaquent les roques
     *
     * @param caseO
     * @param NordSudSelonCouleur
     * @param estOuOuest
     */
    void diagonalePionAttaqueRoque(Case caseO, Direction NordSudSelonCouleur, Direction estOuOuest);

    /**
     * ajoute aux pseudoCoups les coups des pions prise
     *
     * @param caseO
     * @param NordSudSelonCouleur
     * @param estOuOuest
     */
    void diagonalePionPrise(Case caseO, Direction NordSudSelonCouleur, Direction estOuOuest);

    /**
     *  // 0,1,2,3 // 1,2,7,8 (rg1,rg2) = (0,3) ou (2,1)
     *
     * @param rg1
     * @param rg2
     * @param caseX
     * @return
     */
    Boolean caseDuRang(Rang rg1, Rang rg2, Rang caseX);

    /**
     *
     * @param caseX
     * @return true si la case est vide
     */
    Booleen estVide(Case caseX);

    /**
     * execute un coups prise ou deplacement
     *
     * @param gp
     * @param coups
     */
    void exec(Position gp, Coups coups);

    /**
     * execute un coups En Passant
     *
     * @param gp
     * @param coups
     */
    void execEnPassant(Position gp, Coups coups);

    /**
     * execute un coups Promotion du pion
     *
     * @param gp
     * @param coups
     */
    void execPromo(Position gp, Coups coups);

    /**
     *
     * @param caseX
     * @return "true" si la cellule appartient a l'echiquier (est une case)
     */
    Booleen existe(Case caseX);

    /**
     *
     * @param gp
     * @param couleur
     * @return la case du roi couleur
     */
    Case fCaseRoi(Position gp, Couleur couleur);

    /**
     *
     * @param pseudoCoupsPosSimul
     * @param caseRoi
     * @return true si le roi est en echec par les pseudoCoups
     */
    Booleen fEstEnEchec(List<Coups> pseudoCoupsPosSimul, Case caseRoi);

    /**
     *
     * @param coups
     * @return position apres execution de coups
     */
    Position fPositionSimul(Coups coups);

    /**
     *
     * @param gp
     * @return la liste des coups valides
     */
    List<Coups> getCoups(Position gp);

    /**
     *
     * @param caseX
     * @return true si la case est occupée par une piece adverse
     */
    Booleen pieceAdverse(Case caseX);

    /**
     *
     * @param caseO
     * @return true si la case est occupée par une piece qui a le trait
     */
    Booleen pieceQuiALeTrait(Case caseO);

    /**
     *
     * @param caseX
     * @param couleur
     * @return true si la case est occupée par un pion blanc
     */
    Booleen pionCouleur(Case caseX, Couleur couleur);

    /**
     * recherche les coups dit "normaux" ou pseudocoups
     *
     * @return
     */
    List<Coups> pseudoCoups();

    /**
     * ajoute a la liste les coups dit "normaux" ou pseudocoups dans un
     * direction
     *
     * @param caseO
     * @param direction
     */
    void pseudoCoupsDirection(Case caseO, Direction direction);

    /**
     * ajoute a la liste les coups dit "normaux" ou pseudocoups des pieces
     * glissantes dans toutes les directions
     *
     * @param caseO
     * @param directionsPiece
     */
    void pseudoCoupsGlissant(Case caseO, Direction[] directionsPiece);

    /**
     * ajoute a la liste les coups dit "normaux" ou pseudocoups des pieces non
     * glissantes dans toutes les directions
     *
     * @param caseO
     * @param directionsPiece
     */
    void pseudoCoupsNonGlissant(Case caseO, Direction[] directionsPiece);

    /**
     * ajoute a la liste les coups des pions
     *
     * @param caseO
     * @param recherchePionAttaqueRoque
     */
    void pseudoCoupsPion(Case caseO, Booleen recherchePionAttaqueRoque);

    /**
     * ajoute a la liste les coups promotions des pions
     *
     * @param caseO
     * @param caseX
     * @param pieceprise
     */
    void ajouterCoupsPromotion(Case caseO, Case caseX, Piece pieceprise);

    /**
     * retranche a la liste des coups, les coups qui mettent le roi en echec
     *
     * @param fCoups
     * @return
     */
    List<Coups> traiterEchecs(List<Coups> fCoups);

    /**
     * retourne le type d'une piece en case _case
     *
     * @param _case
     * @return
     */
    TypePiece typeDePiece(Case _case);

    void traiterCoupsEPSelonCouleur(Case caseEP, List<GCoups> pCoups, Couleur couleur1, Direction dir);

    void possibleRoque(Couleur color, Rq r, Position pgPosition, Etat[] pgEtats, List<Coups> coupsAttaque, List<Coups> fCoups);

    Integer orientation(Integer couleur);

    void roiPosition(Position gp, Coups coups);

    void retirerCoupsEchec(List<Coups> pCoups);

    void ajouterCoupsEP(List<Coups> pCoups, Piece piece, Case caseX, Case caseEP);

}
