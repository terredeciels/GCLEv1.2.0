package position;

import java.util.List;

public interface ICodage {

    int INFINI = Integer.MAX_VALUE;
    int PAS_DE_CASE = -1;    // e.p.
    String FEN_INITIALE = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    int BLANC = -1, NOIR = 1;

    int a1 = 26, h1 = 33, a8 = 110, h8 = 117;
    int e1 = 30, f1 = 31, g1 = 32, d1 = 29, c1 = 28, b1 = 27;
    int e8 = 114, f8 = 115, g8 = 116, d8 = 113, c8 = 112, b8 = 111;
    int d7 = 101, e7 = 102, d2 = 41, e2 = 42, a2 = 38, h2 = 45, a7 = 98, h7 = 105, d4 = 65, e4 = 66;
    int e6 = 90, f6 = 91, d5 = 77, f3 = 55, c2 = 40, c4 = 64, g7 = 104, g6 = 92;
    int c3 = 52, e3 = 54, a6 = 86, c7 = 100, c5 = 76, b7 = 99, b6 = 87, f7 = 103;
    int b4 = 63, e5 = 78, f5 = 79, a4 = 62, d6 = 89;
    int b2 = 39, f2 = 43, g2 = 44;

    String STRING_COL = "abcdefgh";

    /* 
    Types pièces codés comme dans "Chesspresso"
     */
    int CAVALIER = 1, FOU = 2, TOUR = 3, DAME = 4, PION = 5, ROI = 6;

    int NB_CASES = 64, NB_CELLULES = 144;
    int VIDE = 0, OUT = 9;
    int nord = +12, est = -1, sud = -12, ouest = +1;
    int nordest = nord + est;
    int nordouest = nord + ouest;
    int sudest = sud + est;
    int sudouest = sud + ouest;

    Integer[] rang_1 = {a1, b1, c1, d1, e1, f1, g1, h1};
    Integer[] rang_8 = {a8, b8, c8, d8, e8, f8, g8, h8};
    Integer[] rang_2 = {a2, b2, c2, d2, e2, f2, g2, h2};
    Integer[] rang_7 = {a7, b7, c7, d7, e7, f7, g7, h7};

    /**
     * 0,1,2,3 // 1,2,7,8 (rg1,rg2) = (0,3) ou (2,1)
     */
    Integer[][] rangs = {{a1, b1, c1, d1, e1, f1, g1, h1}, {a2, b2, c2, d2, e2, f2, g2, h2},
    {a7, b7, c7, d7, e7, f7, g7, h7}, {a8, b8, c8, d8, e8, f8, g8, h8}};

    int RANG1 = 0, RANG2 = 1, RANG7 = 2, RANG8 = 3;

    enum TYPE_DE_COUPS {
        Null, Roque, EnPassant, Promotion, Deplacement, Prise, Attaque;
    }

    enum PIECE_TYPE {

        fou(FOU, "B", 350),
        roi(ROI, "K", 0),
        cavalier(CAVALIER, "N", 300),
        pion(PION, "", 100),
        dame(DAME, "Q", 1000),
        tour(TOUR, "R", 550);

        int code;
        String english_fen;
        int value;

        private PIECE_TYPE(int code, String english_fen, int value) {
            this.code = code;
            this.english_fen = english_fen;
            this.value = value;
        }

        public static int getValue(int type_de_piece) {
            switch (type_de_piece) {
                case FOU:
                    return fou.getValue();
                case ROI:
                    return roi.getValue();
                case CAVALIER:
                    return cavalier.getValue();
                case PION:
                    return pion.getValue();
                case DAME:
                    return dame.getValue();
                case TOUR:
                    return tour.getValue();
                default:
                    /* 
                    erreur a gérer
                     */
                    return -1;

            }
        }

        private int getValue() {
            return value;
        }

    }

    class Roque {

        static boolean[] roques = new boolean[4];
        static int trait;

        public static Integer[][] roques_cases = {{e1, g1, h1, f1}, {e1, c1, a1, d1, b1}, {e8, g8, h8, f8}, {e8, c8, a8, d8, b8}};

        public static void setTrait(int trait) {
            Roque.trait = trait;
        }

//        Roque() {
//         
//        }

        /*
        K petit roque blanc
        Q grand roque blanc
        k petit roque noir
        q grand roque noir
         */
        static void unsetRoque() {
            if (trait == BLANC) {
                unsetKQ();
            } else if (trait == NOIR) {
                unsetkq();
            }
        }

        static void unsetKQ() {
            roques[0] = false;
            roques[1] = false;
        }

        static void unsetkq() {
            roques[2] = false;
            roques[3] = false;
        }

        static void unsetK(int color) {
            if (color == BLANC) {
                unsetK();
            } else if (color == NOIR) {
                unsetk();
            }

        }

        static void unsetQ(int color) {
            if (color == BLANC) {
                unsetQ();
            } else if (color == NOIR) {
                unsetq();
            }
        }

        static void unsetK() {
            roques[0] = false;
        }

        static void unsetQ() {
            roques[1] = false;
        }

        static void unsetk() {
            roques[2] = false;
        }

        static void unsetq() {
            roques[3] = false;
        }

        static int caseTourH() {
            return trait == BLANC ? h1 : h8;
        }

        static int caseTourA() {
            return trait == BLANC ? a1 : a8;
        }

        static int caseRoi() {
            return trait == BLANC ? e1 : e8;
        }
    }

}
