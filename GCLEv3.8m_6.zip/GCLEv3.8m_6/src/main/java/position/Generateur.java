package position;

import java.util.*;
import static java.util.Arrays.binarySearch;
import java.util.logging.Level;
import java.util.logging.Logger;
import static position.ACodage.*;
import static position.ICodage.Roque.roques_cases;
import static position.ICodage.TYPE_DE_COUPS.*;

public class Generateur implements ICodage, Cloneable, IGenerateur<Integer, TYPE_DE_COUPS, GCoups, Integer, Integer, GPosition, Integer, Boolean, Integer, Integer, Integer, Integer> {

    ArrayList<GCoups> pseudoCoups;
    boolean recherchePionAttaqueRoque = false;
    GPosition gp;
    int caseRoiBlanc;
    int caseRoiNoir;
    boolean estEnEchec;
    Integer[] etats;
    int couleur;

    //*********************METHODES ELEMENTAIRES**********************
    public Integer orientation(Integer couleur) {
        return couleur == BLANC ? nord : sud;
    }

    public Boolean estVide(Integer caseX) {
        return etats[caseX] == VIDE;
    }

    public Boolean existe(Integer caseX) {
        return etats[caseX] != OUT;
    }

    public Boolean pieceAdverse(Integer caseX) {
        return existe(caseX) && etats[caseX] * couleur < 0;
    }

    public Integer couleurPiece(Integer caseO) {
        return (etats[caseO] < 0) ? BLANC : NOIR;
    }

    public Integer typeDePiece(Integer caseO) {
        return (etats[caseO] < 0) ? -etats[caseO] : etats[caseO];
    }

    public Boolean pionCouleur(Integer caseX, Integer couleur) {
        return typeDePiece(caseX) == PION && couleurPiece(caseX) == couleur;
    }

    public Boolean pieceQuiALeTrait(Integer caseO) {
        return !(caseO == VIDE) && couleurPiece(caseO) == couleur;
    }

    public Boolean caseDuRang(Integer rg1, Integer rg2, Integer caseX) {
        return (binarySearch(rangs[rg1], caseX) >= 0 && couleur == NOIR)
                || (binarySearch(rangs[rg2], caseX) >= 0 && couleur == BLANC);
    }

    //*********************METHODES PRINCIPALES**********************
    public List<GCoups> getCoups(GPosition gp) {
        this.gp = gp;
        this.etats = gp.etats;
        this.caseRoiBlanc = gp.caseRoiBlanc;
        this.caseRoiNoir = gp.caseRoiNoir;
        this.couleur = gp.trait;
        pseudoCoups = new ArrayList<>();

        List<GCoups> pCoups = pseudoCoups();
        traiterRoques(pCoups);
        traiterCoupsEP(pCoups, couleur);
        retirerCoupsEchec(pCoups);
        return pCoups;
    }

    public List<GCoups> pseudoCoups() {
        for (int caseO : CASES117) {
            if (pieceQuiALeTrait(caseO)) {
                switch (typeDePiece(caseO)) {
                    case PION:
                        pseudoCoupsPion(caseO, recherchePionAttaqueRoque);
                        break;
                    case ROI:
                        pseudoCoupsNonGlissant(caseO, DIR_ROI);
                        break;
                    case CAVALIER:
                        pseudoCoupsNonGlissant(caseO, DIR_CAVALIER);
                        break;
                    case TOUR:
                        pseudoCoupsGlissant(caseO, DIR_TOUR);
                        break;
                    case FOU:
                        pseudoCoupsGlissant(caseO, DIR_FOU);
                        break;
                    case DAME:
                        pseudoCoupsGlissant(caseO, DIR_DAME);
                        break;
                    default:
                    //                        return null; //erreur, à traiter
                }
            }
        }

        return pseudoCoups;
    }

    //*********************** AJOUTER COUPS*****************************
    public Boolean ajouterCoups(Integer caseO, Integer caseX, TYPE_DE_COUPS type_de_coups) {
        return pseudoCoups.add(new GCoups(etats[caseO], caseO, caseX, etats[caseX], type_de_coups));
    }

    public void ajouterCoups(Integer piece, Integer caseO, Integer caseX, Integer pieceprise, TYPE_DE_COUPS type_de_coups) {
        pseudoCoups.add(new GCoups(piece, caseO, caseX, pieceprise, type_de_coups));
    }

    public void ajouterCoupsEP(List<GCoups> pCoups, Integer piece, Integer caseX, Integer caseEP) {
        pCoups.add(new GCoups(piece, caseX, caseEP, 0, EnPassant));
    }

    public void ajouterCoupsPromotion(Integer caseO, Integer caseX, Integer pieceprise) {
        pseudoCoups.add(new GCoups(couleur * PION, caseO, caseX, pieceprise, Promotion, couleur * FOU));
        pseudoCoups.add(new GCoups(couleur * PION, caseO, caseX, pieceprise, Promotion, couleur * CAVALIER));
        pseudoCoups.add(new GCoups(couleur * PION, caseO, caseX, pieceprise, Promotion, couleur * DAME));
        pseudoCoups.add(new GCoups(couleur * PION, caseO, caseX, pieceprise, Promotion, couleur * TOUR));
    }

    //*************************EXECUTER COUPS****************************
    public void exec(GPosition gp, GCoups coups) {
        gp.etats[coups.getCaseX()] = gp.etats[coups.getCaseO()];
        gp.etats[coups.getCaseO()] = VIDE;
    }

    public void execEnPassant(GPosition gp, GCoups coups) {
        exec(gp, coups);
        gp.etats[coups.getCaseX() + couleur * nord] = VIDE;
    }

    public void execPromo(GPosition gp, GCoups coups) {
        gp.etats[coups.getCaseX()] = coups.getPiecePromotion();
        gp.etats[coups.getCaseO()] = VIDE;
    }

    //*************************ROQUES**********************************
    public void traiterRoques(List<GCoups> fCoups) {
        // attention: -couleur
        // Generateur pGen = new Generateur();
        Generateur pGen = this.clone();

        pGen.couleur = -couleur;
        pGen.pseudoCoups = new ArrayList<>();

        pGen.recherchePionAttaqueRoque = true;

        for (Integer rq = 0; rq < 4; rq++) {
            possibleRoque(couleur, rq, pGen.gp, pGen.gp.etats, pGen.pseudoCoups(), fCoups);
        }
    }

    public void possibleRoque(Integer color, Integer r, GPosition gp, Integer[] pgEtats, List<GCoups> coupsAttaque, List<GCoups> fCoups) {
        boolean possible;
        Integer _c0 = roques_cases[r][0];
        Integer _c1 = roques_cases[r][1];
        Integer _c2 = roques_cases[r][2];
        Integer _c3 = roques_cases[r][3];
        Integer pgEtats_c4 = r == 1 || r == 3 ? pgEtats[roques_cases[r][4]] : VIDE;
        if (gp.roques[r]) {
            possible = ((pgEtats[_c0] == color * ROI)
                    && (pgEtats[_c2] == color * TOUR)
                    && (pgEtats[_c3] == VIDE)
                    && (pgEtats[_c1] == VIDE)
                    && (pgEtats_c4 == VIDE));
            possible &= !(attaqueRoque(_c0, _c3, _c1, coupsAttaque));
            if (possible) {
                fCoups.add(new GCoups(ROI, _c0, _c1, _c2, _c3, 0, Roque));
            }
        }
    }

    public Boolean attaqueRoque(Integer E1ouE8, Integer F1ouF8, Integer G1ouG8, List<GCoups> coupsAttaque) {

        return coupsAttaque.stream().map((coups)
                -> coups.getCaseX()).anyMatch((caseX)
                -> {
            return Objects.equals(caseX, E1ouE8)
                    || Objects.equals(caseX, F1ouF8)
                    || Objects.equals(caseX, G1ouG8);
        });
    }

    public void diagonalePionAttaqueRoque(Integer caseO, Integer NordSudSelonCouleur, Integer estOuOuest) {
        int caseX = caseO + NordSudSelonCouleur + estOuOuest;
        if (existe(caseX)) {
            ajouterCoups(couleur * PION, caseO, caseX, etats[caseX], Attaque);
        }
    }

    //*************************E.P.***************************************
    public void traiterCoupsEP(List<GCoups> pCoups, Integer couleur) {
        final int caseEP = gp.caseEP;
        // prise en passant (avant recherche d'échecs)
        if (caseEP != PAS_DE_CASE) {
            traiterCoupsEPSelonCouleur(caseEP, pCoups, couleur, orientation(-couleur));
        }
    }

    public void traiterCoupsEPSelonCouleur(Integer caseEP, List<GCoups> pCoups, Integer color, Integer dir) {
        int caseX = caseEP + dir + est;
        if (pionCouleur(caseX, color)) {
            ajouterCoupsEP(pCoups, color * PION, caseX, caseEP);
        }
        caseX = caseEP + dir + ouest;
        if (pionCouleur(caseX, color)) {
            ajouterCoupsEP(pCoups, color * PION, caseX, caseEP);
        }
    }

    //************************ECHECS************************************
    public Integer fCaseRoi(GPosition gp, Integer couleur) {
        return couleur == BLANC ? gp.caseRoiBlanc : gp.caseRoiNoir;
    }

    public Boolean fEstEnEchec(List<GCoups> pseudoCoupsPosSimul, Integer caseRoi) {
        boolean isCheck = false;
        for (GCoups coups : pseudoCoupsPosSimul) {
            if (coups.getCaseX() == caseRoi) {
                isCheck = true;
                break;
            }
        }
        return isCheck;
    }

    public GPosition fPositionSimul(GCoups coups) {
        GPosition gpos = new GPosition();
        System.arraycopy(etats, 0, gpos.etats, 0, NB_CELLULES);
        roiPosition(gpos, coups);

        switch (coups.getTypeDeCoups()) {
            case Deplacement:
            case Prise:
                exec(gpos, coups);
                break;
            case EnPassant:
                execEnPassant(gpos, coups);
                break;
            case Promotion:
                execPromo(gpos, coups);
                break;
        }
        return gpos;
    }

    public void roiPosition(GPosition gp, GCoups coups) {
        gp.caseRoiBlanc = caseRoiBlanc;
        gp.caseRoiNoir = caseRoiNoir;

        if (etats[coups.getCaseO()] == BLANC * ROI) {
            gp.caseRoiBlanc = coups.getCaseX(); //nouvelle pos du roi
        } else if (etats[coups.getCaseO()] == NOIR * ROI) {
            gp.caseRoiNoir = coups.getCaseX();
        }
    }

    public void retirerCoupsEchec(List<GCoups> pCoups) {
        pCoups.removeAll(traiterEchecs(pCoups));
    }

    public List<GCoups> traiterEchecs(List<GCoups> fCoups) {
        ArrayList<GCoups> aRetirer = new ArrayList<>();
        for (GCoups coups : fCoups) {
            GPosition gpos = fPositionSimul(coups);
            // attention: -couleur
            Generateur pGen = this.clone();
//            Generateur pGen = new Generateur(); 
            pGen.gp = gpos;
            pGen.etats = gpos.etats;
            pGen.caseRoiBlanc = gpos.caseRoiBlanc;
            pGen.caseRoiNoir = gpos.caseRoiNoir;
            pGen.couleur = gpos.trait;
            pGen.couleur = -couleur;
            pGen.pseudoCoups = new ArrayList<>();
            pGen.pseudoCoups();
            estEnEchec = fEstEnEchec(pGen.pseudoCoups, fCaseRoi(gpos, couleur));
            if (estEnEchec) {
                aRetirer.add(coups);
            }
        }
        return aRetirer;
    }

    //***********************DEPLACEMENTS*******************************
    public void diagonalePionPrise(Integer caseO, Integer NordSudSelonCouleur, Integer estOuOuest) {
        int caseX = caseO + NordSudSelonCouleur + estOuOuest;
        if (pieceAdverse(caseX)) {

            if (caseDuRang(RANG1, RANG8, caseX)) {
                ajouterCoupsPromotion(caseO, caseX, etats[caseX]);
            } else {
                ajouterCoups(couleur * PION, caseO, caseX, etats[caseX], Prise);
            }
        }
    }

    public void pseudoCoupsDirection(Integer caseO, Integer direction) {
        int caseX = caseO + direction;
        int etatX = etats[caseX];
        while (etatX == VIDE) {
            ajouterCoups(caseO, caseX, Deplacement);
            caseX = caseX + direction;
            etatX = etats[caseX];
        }
        if (pieceAdverse(caseX)) {
            ajouterCoups(caseO, caseX, Prise);
        }
    }

    public void pseudoCoupsGlissant(Integer caseO, Integer[] directionsPiece) {
        for (int directionX : directionsPiece) {
            pseudoCoupsDirection(caseO, directionX);
        }
    }

    public void pseudoCoupsNonGlissant(Integer caseO, Integer[] directionsPiece) {
        int caseX;
        for (int directionX : directionsPiece) {
            caseX = caseO + directionX;
            if (estVide(caseX)) {
                ajouterCoups(caseO, caseX, Deplacement);
            } else if (pieceAdverse(caseX)) {
                ajouterCoups(caseO, caseX, Prise);
            }
        }
    }

    public void pseudoCoupsPion(Integer caseO, Boolean recherchePionAttaqueRoque) {
        int NordSudSelonCouleur = orientation(couleur);
        // avances du pion
        int caseX = caseO + NordSudSelonCouleur;
        if (estVide(caseX)) {
            if (caseDuRang(RANG1, RANG8, caseX)) {
                ajouterCoupsPromotion(caseO, caseX, 0);
            } else {
                ajouterCoups(couleur * PION, caseO, caseX, 0, Deplacement);
            }
            if (caseDuRang(RANG7, RANG2, caseO)) {
                caseX = caseO + 2 * NordSudSelonCouleur;
                if (estVide(caseX)) {
                    ajouterCoups(couleur * PION, caseO, caseX, 0, Deplacement);
                }
            }

        }
        // diagonales du pion (prise)
        if (!recherchePionAttaqueRoque) {
            diagonalePionPrise(caseO, NordSudSelonCouleur, est);
            diagonalePionPrise(caseO, NordSudSelonCouleur, ouest);
        } else {
            // diagonales du pion (attaque)
            diagonalePionAttaqueRoque(caseO, NordSudSelonCouleur, est);
            diagonalePionAttaqueRoque(caseO, NordSudSelonCouleur, ouest);
        }
    }

    @Override
    public Generateur clone() {

        try {
            return (Generateur) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new InternalError(e);
        }

    }
}
