package position;

import java.util.ArrayList;
import java.util.Collections;
import org.chesspresso.Chess;
import org.chesspresso.move.Move;
import org.chesspresso.position.Position;
import static position.ACodage.*;

public class FenToGPosition implements ICodage {

    public static GPosition toGPosition(String fen) {
        return toGPosition(new Position(fen));
    }

    private static GPosition toGPosition(Position position) {

        GPosition gp = new GPosition();
//        gp.position = position;

        gp.fen = position.getFEN();
//        gp.cp_coupsvalides_lan = getStringCPCoupsValides(position.getAllMoves());
        /*
        @TODO debug cp_etats
         */
        final Integer[] cp_etats = new Integer[NB_CASES];
//        int[] cp_etats = new int[NB_CASES];
        for (final int caseO : CASES64) {
            cp_etats[caseO] = position.getStone(caseO);  // !! getStone et non getPiece
        }
        Integer[] etats = new Integer[NB_CELLULES];
        for (int caseO = 0; caseO < NB_CELLULES; caseO++) {
            etats[caseO] = OUT;
        }
        for (int index = 0; index < cp_etats.length; index++) {
            int cp_etat = cp_etats[index];
            etats[CASES117[index]] = cp_etat;

            if (cp_etat == BLANC * ROI) {
                gp.caseRoiBlanc = CASES117[index];
            } else if (cp_etat == NOIR * ROI) {
                gp.caseRoiNoir = CASES117[index];
            }
        }

        gp.etats = etats;

        gp.trait = position.getToPlay() == Chess.WHITE ? BLANC : NOIR;

        // cp_roques - cf note_tad.txt
        int cp_roques = position.getCastles();

        gp.roques[0] = (2 & cp_roques) == 2;
        gp.roques[1] = (1 & cp_roques) == 1;
        gp.roques[2] = (8 & cp_roques) == 8;
        gp.roques[3] = (4 & cp_roques) == 4;

        gp.caseEP = position.getSqiEP() == PAS_DE_CASE ? -1 : CASES117[position.getSqiEP()];

        return gp;
    }

    public static ArrayList<String> getStringCPCoupsValides(short[] cp_coupsvalides) {
        ArrayList<String> cp_coupsvalides_lan = new ArrayList<>();
        for (short m : cp_coupsvalides) {
            cp_coupsvalides_lan.add(Move.getString(m));

        }
        Collections.sort(cp_coupsvalides_lan);
        return cp_coupsvalides_lan;
    }

}
