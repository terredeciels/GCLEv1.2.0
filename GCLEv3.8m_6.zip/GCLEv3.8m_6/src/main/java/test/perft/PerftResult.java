package test.perft;

public class PerftResult {

    public long moveCount = 0;
    public long timeTaken = 0;

}
