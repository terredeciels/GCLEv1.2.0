package test.mailbox;

public class MoveGen {
//https://chessprogramming.wikispaces.com/10x12+Board

    int[] color;
    /* LIGHT, DARK, or EMPTY */
    int[] piece;
    /* PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING, or EMPTY */
    int[] mailbox = {
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
        -1, 0, 1, 2, 3, 4, 5, 6, 7, -1,
        -1, 8, 9, 10, 11, 12, 13, 14, 15, -1,
        -1, 16, 17, 18, 19, 20, 21, 22, 23, -1,
        -1, 24, 25, 26, 27, 28, 29, 30, 31, -1,
        -1, 32, 33, 34, 35, 36, 37, 38, 39, -1,
        -1, 40, 41, 42, 43, 44, 45, 46, 47, -1,
        -1, 48, 49, 50, 51, 52, 53, 54, 55, -1,
        -1, 56, 57, 58, 59, 60, 61, 62, 63, -1,
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
    };

    int[] mailbox64 = {
        21, 22, 23, 24, 25, 26, 27, 28,
        31, 32, 33, 34, 35, 36, 37, 38,
        41, 42, 43, 44, 45, 46, 47, 48,
        51, 52, 53, 54, 55, 56, 57, 58,
        61, 62, 63, 64, 65, 66, 67, 68,
        71, 72, 73, 74, 75, 76, 77, 78,
        81, 82, 83, 84, 85, 86, 87, 88,
        91, 92, 93, 94, 95, 96, 97, 98
    };
    boolean[] slide = {false, false, true, true, true, false};/* PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING, or EMPTY */
    int[] offsets = {0, 8, 4, 4, 8, 8};/* knight or ray directions */
    int[][] offset = {
        {0, 0, 0, 0, 0, 0, 0, 0},
        {-21, -19, -12, -8, 8, 12, 19, 21}, /* KNIGHT */
        {-11, -9, 9, 11, 0, 0, 0, 0}, /* BISHOP */
        {-10, -1, 1, 10, 0, 0, 0, 0}, /* ROOK */
        {-11, -10, -9, -1, 1, 9, 10, 11}, /* QUEEN */
        {-11, -10, -9, -1, 1, 9, 10, 11} /* KING */};

    public static void main(String[] args) {

    }
    private int PION;
    private int EMPTY;

    public MoveGen() {
        mailbox = new int[120];
        mailbox64 = new int[64];
        assert (mailbox64.length == 64);
        assert (mailbox.length == 120);
        color = new int[64];
        piece = new int[64];
    }

    void getValidMoves(int side) {
//        int side;
        /* the side to move */
        int xside = -side;
        /* the side not to move */

        for (int i = 0; i < 64; ++i) {
            /* loop over all squares (no piece list) */
            if (color[i] == side) {
                /* looking for own pieces and pawns to move */
                int p = piece[i];
                /* found one */
                if (p != PION) {
                    /* piece or pawn */
                    for (int j = 0; j < offsets[p]; ++j) {
                        /* for all knight or ray directions */
                        for (int n = i;;) {
                            /* starting with from square */
                            n = mailbox[mailbox64[n] + offset[p][j]];
                            /* next square along the ray j */
                            if (n == -1) {
                                break;
                                /* outside board */
                            }
                            if (color[n] != EMPTY) {
                                if (color[n] == xside) {
                                    genMove(i, n, true);
                                    /* capture from i to n */
                                }
                                break;
                            }
                            genMove(i, n, false);
                            /* quiet move from i to n */
                            if (!slide[p]) {
                                break;
                                /* next direction */
                            }
                        }
                    }
                } else {
                    /* pawn moves */ }
            }
        }
    }

    private void genMove(int caseO, int caseX, boolean prise) {

    }
}
